"""
====================================================================
 WHATSAPP BULK SENDER - ENTERPRISE TERMINAL EDITION (FINAL FIXED)
====================================================================

HOW TO RUN:
1. pip install selenium webdriver-manager pandas rich
2. python main.py

====================================================================
 INPUT FORMATS
====================================================================

CSV FORMAT:
number
923001112233
923441112233

MANUAL FORMAT:
923001112233
923441112233
DONE

MESSAGE FORMAT:
Hello
This is message
END

====================================================================
 IMPORTANT RULES
====================================================================

✔ Use only country-code numbers (no +, no spaces)
✔ Example: 923001112233
✔ Excel must be formatted as TEXT
✔ DONE = finish manual input
✔ END = finish message input

====================================================================
"""

# ========================= IMPORTS =========================

import os
import re
import time
import urllib.parse
import traceback
from pathlib import Path
from typing import List, Set

import pandas as pd

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException,
    WebDriverException,
    StaleElementReferenceException,
    InvalidSessionIdException,
)

from webdriver_manager.chrome import ChromeDriverManager

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt, IntPrompt
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn

# ========================= UI =========================

console = Console()

LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

DONE_FILE = Path("done_numbers.txt")

CHAT_XPATH = "//footer//div[@contenteditable='true']"

WHATSAPP_URL = "https://web.whatsapp.com"

MAX_RETRIES = 2


# ========================= VALIDATION =========================

def clean_number(n: str) -> str:
    if pd.isna(n):
        return ""
    n = str(n).strip()
    n = re.sub(r"[^\d]", "", n)
    return n


def is_valid_number(n: str) -> bool:
    return n.isdigit() and 10 <= len(n) <= 15


# ========================= DRIVER =========================

def get_driver():
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-notifications")
    options.add_argument("--no-sandbox")

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options
    )

    return driver


# ========================= CONTACT LOADER =========================

def load_contacts() -> List[str]:

    console.print(Panel(
        "1 = CSV FILE\n2 = MANUAL INPUT",
        title="CONTACT INPUT"
    ))

    choice = Prompt.ask("Select", choices=["1", "2"])

    numbers = []

    try:

        if choice == "1":

            path = Prompt.ask("CSV Path")
            df = pd.read_csv(path, dtype=str)

            col = None
            for c in df.columns:
                if c.lower() in ["number", "phone", "mobile"]:
                    col = c
                    break

            if not col:
                raise ValueError("CSV must have number/phone/mobile column")

            numbers = df[col].tolist()

        else:

            console.print(Panel(
                "Enter numbers one per line\nType DONE to finish",
                title="MANUAL INPUT"
            ))

            while True:
                v = Prompt.ask("Number")

                if v.upper() == "DONE":
                    break

                numbers.append(v)

    except Exception as e:
        console.print(f"[red]Error: {e}")
        return []

    clean = []
    seen = set()

    for n in numbers:
        n = clean_number(n)

        if not is_valid_number(n):
            continue

        if n not in seen:
            seen.add(n)
            clean.append(n)

    return clean


# ========================= MESSAGE =========================

def get_message():

    console.print(Panel(
        "Type message\nEND to finish",
        title="MESSAGE INPUT"
    ))

    lines = []

    while True:
        l = input()
        if l.strip().upper() == "END":
            break
        lines.append(l)

    return "\n".join(lines)


# ========================= WHATSAPP CHECK =========================

def invalid_number(driver):

    texts = driver.page_source.lower()

    return (
        "phone number shared via url is invalid" in texts or
        "phone number is invalid" in texts or
        "not on whatsapp" in texts
    )


# ========================= SEND MESSAGE =========================

def send(driver, number, message):

    try:

        url = f"https://web.whatsapp.com/send?phone={number}&text={urllib.parse.quote(message)}"
        driver.get(url)

        time.sleep(5)

        if invalid_number(driver):
            return False

        wait = WebDriverWait(driver, 30)

        box = wait.until(
            EC.presence_of_element_located((By.XPATH, CHAT_XPATH))
        )

        box.send_keys(Keys.ENTER)

        time.sleep(2)

        return True

    except Exception:
        return False


# ========================= DONE SYSTEM =========================

def load_done():

    if not DONE_FILE.exists():
        return set()

    return set(DONE_FILE.read_text().splitlines())


def save_done(n):
    with open(DONE_FILE, "a") as f:
        f.write(n + "\n")


# ========================= MAIN =========================

def main():

    console.print(Panel("WHATSAPP BULK SENDER", style="green"))

    contacts = load_contacts()

    if not contacts:
        console.print("[red]No contacts")
        return

    msg = get_message()

    delay = IntPrompt.ask("Delay (sec)", default=5)

    driver = get_driver()

    driver.get(WHATSAPP_URL)

    input("Scan QR and press ENTER")

    done = load_done()

    success = 0
    failed = 0
    skipped = 0

    progress = Progress(
        SpinnerColumn(),
        TextColumn("{task.description}"),
        BarColumn(),
    )

    with progress:

        task = progress.add_task("Sending", total=len(contacts))

        for i, n in enumerate(contacts):

            if n in done:
                skipped += 1
                progress.advance(task)
                continue

            ok = False

            for _ in range(MAX_RETRIES + 1):

                ok = send(driver, n, msg)
                if ok:
                    break

                time.sleep(2)

            if ok:
                success += 1
                save_done(n)
            else:
                failed += 1

            progress.advance(task)
            time.sleep(delay)

    console.print(Panel(
        f"SUCCESS: {success}\nFAILED: {failed}\nSKIPPED: {skipped}",
        title="FINAL REPORT"
    ))

    driver.quit()


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        console.print(f"[red]Fatal: {e}")
        traceback.print_exc()