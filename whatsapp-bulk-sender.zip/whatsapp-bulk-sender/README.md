# 📌 WhatsApp Bulk Sender (Python Automation Tool)

A Python-based WhatsApp messaging automation tool built using Selenium WebDriver. It automates sending messages through WhatsApp Web to multiple contacts using CSV or manual input. This project demonstrates practical automation engineering using Python.

---

## 🚀 Features

✔ WhatsApp Web automation using Selenium
✔ CSV file or manual number input
✔ Multi-line message support
✔ Automatic message sending system
✔ Duplicate number prevention (resume support)
✔ Retry mechanism for failed messages
✔ Live progress tracking (Rich CLI interface)
✔ Clean terminal-based workflow

---

## 🧠 Skills & Concepts Used

* Selenium Web Automation
* Browser session handling
* DOM interaction using XPath
* Data validation & cleaning
* CSV file processing (Pandas)
* CLI application design
* Exception handling & retry logic
* Workflow automation system design

---

## ⚙️ How It Works

1. User selects input method (CSV or Manual)
2. System loads and cleans phone numbers
3. User enters multi-line message
4. Selenium opens WhatsApp Web
5. User scans QR code (login step)
6. Messages are sent automatically
7. Results (success/failure/skipped) are shown

---

## 📂 Input Format

CSV Format:
number
923001112233
923441112233

Manual Input:
923001112233
923441112233
DONE

Message Format:
Hello
This is a test message
How are you?
END

---

## 📦 Installation

pip install -r requirements.txt

---

## ▶️ Run Project

python main.py

---

## 💡 Requirements

* Python 3.8+
* Google Chrome Browser
* Internet Connection

---

## 📊 Use Cases

* Small business messaging automation
* Educational Selenium practice project
* Personal productivity tool
* Prototype CRM communication system
* Bulk notification testing tool

---

## 💼 Professional Services

This project can be upgraded into a fully production-ready system using Meta WhatsApp Business API (official WhatsApp Cloud API platform).

I provide freelance development services for:

* WhatsApp Business API integration
* Business automation systems
* CRM-based messaging solutions
* Scalable communication platforms
* Custom workflow automation tools

📩 Contact for freelance work or custom development:
📞 0327-2772620
📧 [engumarabdullah@gmail.com](mailto:engumarabdullah@gmail.com)

---

## 👨‍💻 Author

Name: Umer Arain
Email: [engumarabdullah@gmail.com](mailto:engumarabdullah@gmail.com)
Phone: 0327-2772620

---

## ⚠️ Disclaimer

This project is intended for educational and small-scale automation use only. It demonstrates how browser automation works using Selenium.

For enterprise-grade systems, official API-based solutions are recommended using Meta WhatsApp Business API (official WhatsApp Cloud API platform).

---

## 📌 Note

Use responsibly and avoid misuse such as spam or large-scale unsolicited messaging.


